const form = document.getElementById('adminLoginForm');
const msg = document.getElementById('formMsg');
const submitBtn = document.getElementById('submitBtn');

function showMsg(text, type) {
  msg.textContent = text;
  msg.className = `form-msg ${type || ''}`;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  showMsg('', '');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Memproses...';

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;

  try {
    const res = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();

    if (!res.ok || !data.ok) {
      showMsg(data.error || 'Gagal masuk sebagai admin.', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Masuk sebagai admin';
      return;
    }

    showMsg('Berhasil masuk, mengarahkan...', 'success');
    window.location.href = data.redirect || '/admin-chat.html';
  } catch (err) {
    showMsg('Terjadi kesalahan jaringan. Coba lagi.', 'error');
    submitBtn.disabled = false;
    submitBtn.textContent = 'Masuk sebagai admin';
  }
});
