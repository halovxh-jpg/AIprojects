(async () => {
  const me = await FreqChat.requireAuth('user', '/login.html');
  if (!me) return;

  document.getElementById('usernameTag').textContent = `@${me.username}`;
  FreqChat.bindLogout('logoutBtn', '/login.html');

  const scrollEl = document.getElementById('chatScroll');
  const emptyEl = document.getElementById('chatEmpty');
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatInput');
  const sendBtn = document.getElementById('sendBtn');

  FreqChat.autoResizeTextarea(input);

  // Muat riwayat chat
  try {
    const res = await fetch('/api/chat/history');
    const data = await res.json();
    if (data.ok && data.history.length > 0) {
      emptyEl.remove();
      data.history.forEach((m) => {
        FreqChat.appendBubble(scrollEl, m.sender === 'ai' ? 'ai' : 'user', m.content);
      });
    }
  } catch (err) {
    // biarkan tampilan kosong kalau gagal load history
  }

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form.requestSubmit();
    }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = input.value.trim();
    if (!message) return;

    if (emptyEl && emptyEl.parentNode) emptyEl.remove();

    FreqChat.appendBubble(scrollEl, 'user', message);
    input.value = '';
    input.style.height = 'auto';
    input.disabled = true;
    sendBtn.disabled = true;

    const typingRow = FreqChat.appendTypingIndicator(scrollEl);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
      const data = await res.json();
      typingRow.remove();

      if (!res.ok || !data.ok) {
        FreqChat.appendBubble(scrollEl, 'ai', data.error || 'Maaf, terjadi kesalahan.');
      } else {
        FreqChat.appendBubble(scrollEl, 'ai', data.reply);
      }
    } catch (err) {
      typingRow.remove();
      FreqChat.appendBubble(scrollEl, 'ai', 'Koneksi terputus. Coba kirim lagi ya.');
    } finally {
      input.disabled = false;
      sendBtn.disabled = false;
      input.focus();
    }
  });
})();
