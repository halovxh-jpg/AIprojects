const form = document.getElementById('adminRegisterForm');
const msg = document.getElementById('formMsg');
const submitBtn = document.getElementById('submitBtn');

function showMsg(text, type) {
  msg.textContent = text;
  msg.className = `form-msg ${type || ''}`;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  showMsg('', '');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Memproses...';

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const staffKey = document.getElementById('staffKey').value;

  try {
    const res = await fetch('/api/admin/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, staffKey }),
    });
    const data = await res.json();

    if (!res.ok || !data.ok) {
      showMsg(data.error || 'Gagal mendaftar sebagai admin.', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Daftar admin';
      return;
    }

    showMsg('Akun admin berhasil dibuat! Mengarahkan ke halaman masuk...', 'success');
    setTimeout(() => {
      window.location.href = '/admin-login.html';
    }, 900);
  } catch (err) {
    showMsg('Terjadi kesalahan jaringan. Coba lagi.', 'error');
    submitBtn.disabled = false;
    submitBtn.textContent = 'Daftar admin';
  }
});
