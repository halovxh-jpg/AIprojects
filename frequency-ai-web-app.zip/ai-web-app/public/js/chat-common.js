const FreqChat = (() => {
  async function requireAuth(expectedRole, redirectIfMissing) {
    try {
      const res = await fetch('/api/me');
      if (!res.ok) {
        window.location.href = redirectIfMissing;
        return null;
      }
      const data = await res.json();
      if (!data.ok || data.role !== expectedRole) {
        window.location.href = redirectIfMissing;
        return null;
      }
      return data;
    } catch (err) {
      window.location.href = redirectIfMissing;
      return null;
    }
  }

  function bindLogout(btnId, redirectTo) {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try {
        await fetch('/api/logout', { method: 'POST' });
      } catch (err) {
        // lanjut redirect walau gagal, cookie tetap akan expire
      }
      window.location.href = redirectTo;
    });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function appendBubble(scrollEl, sender, text) {
    const row = document.createElement('div');
    row.className = `bubble-row from-${sender}`;
    const bubble = document.createElement('div');
    bubble.className = 'bubble';
    bubble.textContent = text;
    row.appendChild(bubble);
    scrollEl.appendChild(row);
    scrollEl.scrollTop = scrollEl.scrollHeight;
    return row;
  }

  function appendTypingIndicator(scrollEl) {
    const row = document.createElement('div');
    row.className = 'bubble-row from-ai typing-row';
    row.innerHTML = `<div class="bubble"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>`;
    scrollEl.appendChild(row);
    scrollEl.scrollTop = scrollEl.scrollHeight;
    return row;
  }

  function autoResizeTextarea(textarea) {
    textarea.addEventListener('input', () => {
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.min(textarea.scrollHeight, 140)}px`;
    });
  }

  return { requireAuth, bindLogout, appendBubble, appendTypingIndicator, autoResizeTextarea, escapeHtml };
})();
