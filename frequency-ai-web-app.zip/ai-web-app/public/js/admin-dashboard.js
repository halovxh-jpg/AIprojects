(async () => {
  const me = await FreqChat.requireAuth('admin', '/admin-login.html');
  if (!me) return;

  FreqChat.bindLogout('logoutBtn', '/admin-login.html');

  const tableEl = document.getElementById('userTable');
  const msgEl = document.getElementById('formMsg');

  function showMsg(text, type) {
    msgEl.textContent = text;
    msgEl.className = `form-msg ${type || ''}`;
  }

  function renderUsers(users) {
    if (!users.length) {
      tableEl.innerHTML = '<div class="dash-empty">Belum ada pengguna yang terdaftar.</div>';
      return;
    }

    tableEl.innerHTML = '';
    users.forEach((u) => {
      const row = document.createElement('div');
      row.className = 'user-row';

      const info = document.createElement('div');
      info.className = 'u-info';

      const name = document.createElement('div');
      name.className = 'u-name';
      name.textContent = `@${u.username}`;

      const meta = document.createElement('div');
      meta.className = 'u-meta';
      meta.textContent = `Daftar: ${new Date(u.created_at).toLocaleDateString('id-ID')}`;

      const pill = document.createElement('span');
      pill.className = `status-pill ${u.banned ? 'banned' : 'active'}`;
      pill.textContent = u.banned ? 'Dibanned' : 'Aktif';

      info.appendChild(name);
      info.appendChild(meta);
      info.appendChild(pill);

      const btn = document.createElement('button');
      btn.className = `ban-btn ${u.banned ? 'unban' : 'ban'}`;
      btn.textContent = u.banned ? 'Buka blokir' : 'Ban akun';
      btn.addEventListener('click', () => toggleBan(u.username, !u.banned, btn));

      row.appendChild(info);
      row.appendChild(btn);
      tableEl.appendChild(row);
    });
  }

  async function loadUsers() {
    try {
      const res = await fetch('/api/admin/users');
      const data = await res.json();
      if (!res.ok || !data.ok) {
        tableEl.innerHTML = '<div class="dash-empty">Gagal memuat daftar pengguna.</div>';
        return;
      }
      renderUsers(data.users);
    } catch (err) {
      tableEl.innerHTML = '<div class="dash-empty">Gagal memuat daftar pengguna.</div>';
    }
  }

  async function toggleBan(username, banned, btn) {
    btn.disabled = true;
    showMsg('', '');
    try {
      const res = await fetch('/api/admin/ban', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, banned }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        showMsg(data.error || 'Gagal mengubah status akun.', 'error');
        btn.disabled = false;
        return;
      }
      showMsg(
        banned ? `@${username} telah dibanned.` : `@${username} telah dibuka blokirnya.`,
        'success'
      );
      loadUsers();
    } catch (err) {
      showMsg('Terjadi kesalahan jaringan.', 'error');
      btn.disabled = false;
    }
  }

  loadUsers();
})();
