const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const { loadEnv } = require('./env');
loadEnv();

const {
  createUser,
  findUserByUsername,
  findUserById,
  listUsersByRole,
  setBanStatus,
  addChatMessage,
  getChatHistory,
} = require('./db');
const {
  hashPassword,
  verifyPassword,
  createSession,
  getSession,
  destroySession,
  parseCookies,
} = require('./auth');
const { callAI } = require('./ai');

const PORT = process.env.PORT || 3000;
const STAFF_KEY = process.env.STAFF_KEY || '67COOL67';
const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_COOKIE = 'sid';

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

// ---------- Helper: body parsing ----------
function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    let size = 0;
    const MAX_SIZE = 1024 * 1024; // 1MB, cegah payload raksasa
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_SIZE) {
        reject(new Error('Payload terlalu besar'));
        req.destroy();
        return;
      }
      data += chunk;
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (e) {
        reject(new Error('JSON tidak valid'));
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, statusCode, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    ...extraHeaders,
  });
  res.end(body);
}

function setSessionCookie(res, sessionId) {
  res.setHeader(
    'Set-Cookie',
    `${SESSION_COOKIE}=${sessionId}; HttpOnly; Path=/; Max-Age=${60 * 60 * 24 * 7}; SameSite=Lax`
  );
}

function clearSessionCookie(res) {
  res.setHeader('Set-Cookie', `${SESSION_COOKIE}=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax`);
}

function getSessionFromReq(req) {
  const cookies = parseCookies(req.headers.cookie);
  return getSession(cookies[SESSION_COOKIE]);
}

// ---------- Validasi input ----------
function validCredentials(username, password) {
  if (typeof username !== 'string' || typeof password !== 'string') return false;
  const uname = username.trim();
  if (uname.length < 3 || uname.length > 32) return false;
  if (!/^[a-zA-Z0-9_.]+$/.test(uname)) return false;
  if (password.length < 6 || password.length > 128) return false;
  return true;
}

// ---------- Static file serving ----------
function serveStatic(req, res, urlPath) {
  let filePath = urlPath === '/' ? '/index.html' : urlPath;
  filePath = filePath.split('?')[0];
  const fullPath = path.normalize(path.join(PUBLIC_DIR, filePath));

  // Cegah path traversal
  if (!fullPath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  fs.readFile(fullPath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        fs.readFile(path.join(PUBLIC_DIR, '404.html'), (err2, notFoundContent) => {
          res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(notFoundContent || '404 Not Found');
        });
      } else {
        res.writeHead(500);
        res.end('Server error');
      }
      return;
    }
    const ext = path.extname(fullPath);
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

// ---------- Route handlers ----------
async function handleRegister(req, res) {
  const body = await readJsonBody(req);
  const { username, password } = body;

  if (!validCredentials(username, password)) {
    return sendJson(res, 400, {
      ok: false,
      error: 'Username minimal 3 karakter (huruf/angka/_/.) dan password minimal 6 karakter.',
    });
  }

  const uname = username.trim();
  if (findUserByUsername(uname)) {
    return sendJson(res, 409, { ok: false, error: 'Username sudah dipakai.' });
  }

  const passwordHash = hashPassword(password);
  createUser({ username: uname, passwordHash, role: 'user' });
  return sendJson(res, 201, { ok: true, message: 'Registrasi berhasil, silakan login.' });
}

async function handleLogin(req, res) {
  const body = await readJsonBody(req);
  const { username, password } = body;

  if (!validCredentials(username, password)) {
    return sendJson(res, 400, { ok: false, error: 'Username atau password tidak valid.' });
  }

  const user = findUserByUsername(username.trim());
  if (!user || user.role !== 'user' || !verifyPassword(password, user.password)) {
    return sendJson(res, 401, { ok: false, error: 'Username atau password salah.' });
  }

  if (user.banned) {
    return sendJson(res, 403, { ok: false, error: 'Akun kamu telah dibanned oleh admin.' });
  }

  const sessionId = createSession(user.id, user.role);
  setSessionCookie(res, sessionId);
  return sendJson(res, 200, { ok: true, redirect: '/chat.html' });
}

async function handleAdminRegister(req, res) {
  const body = await readJsonBody(req);
  const { username, password, staffKey } = body;

  if (!validCredentials(username, password)) {
    return sendJson(res, 400, {
      ok: false,
      error: 'Username minimal 3 karakter (huruf/angka/_/.) dan password minimal 6 karakter.',
    });
  }

  if (staffKey !== STAFF_KEY) {
    return sendJson(res, 403, { ok: false, error: 'Kunci staff salah.' });
  }

  const uname = username.trim();
  if (findUserByUsername(uname)) {
    return sendJson(res, 409, { ok: false, error: 'Username sudah dipakai.' });
  }

  const passwordHash = hashPassword(password);
  createUser({ username: uname, passwordHash, role: 'admin' });
  return sendJson(res, 201, { ok: true, message: 'Registrasi admin berhasil, silakan login.' });
}

async function handleAdminLogin(req, res) {
  const body = await readJsonBody(req);
  const { username, password } = body;

  if (!validCredentials(username, password)) {
    return sendJson(res, 400, { ok: false, error: 'Username atau password tidak valid.' });
  }

  const user = findUserByUsername(username.trim());
  if (!user || user.role !== 'admin' || !verifyPassword(password, user.password)) {
    return sendJson(res, 401, { ok: false, error: 'Username, password, atau akses admin salah.' });
  }

  const sessionId = createSession(user.id, user.role);
  setSessionCookie(res, sessionId);
  return sendJson(res, 200, { ok: true, redirect: '/admin-chat.html' });
}

function handleLogout(req, res) {
  const cookies = parseCookies(req.headers.cookie);
  if (cookies[SESSION_COOKIE]) destroySession(cookies[SESSION_COOKIE]);
  clearSessionCookie(res);
  return sendJson(res, 200, { ok: true });
}

function handleMe(req, res) {
  const session = getSessionFromReq(req);
  if (!session) return sendJson(res, 401, { ok: false });
  const user = findUserById(session.userId);
  if (!user) return sendJson(res, 401, { ok: false });
  return sendJson(res, 200, {
    ok: true,
    username: user.username,
    role: user.role,
  });
}

async function handleChat(req, res, persona) {
  const session = getSessionFromReq(req);
  if (!session || session.role !== persona) {
    return sendJson(res, 401, { ok: false, error: 'Kamu harus login untuk chat.' });
  }
  const user = findUserById(session.userId);
  if (!user || (persona === 'user' && user.banned)) {
    return sendJson(res, 403, { ok: false, error: 'Akses ditolak.' });
  }

  const body = await readJsonBody(req);
  const message = typeof body.message === 'string' ? body.message.trim() : '';
  if (!message || message.length > 4000) {
    return sendJson(res, 400, { ok: false, error: 'Pesan kosong atau terlalu panjang (maks 4000 karakter).' });
  }

  const history = getChatHistory(user.id, 20);
  addChatMessage(user.id, 'user', message);

  const result = await callAI(message, history, persona);
  addChatMessage(user.id, 'ai', result.text);

  return sendJson(res, 200, { ok: true, reply: result.text });
}

function handleChatHistory(req, res, persona) {
  const session = getSessionFromReq(req);
  if (!session || session.role !== persona) {
    return sendJson(res, 401, { ok: false, error: 'Kamu harus login.' });
  }
  const history = getChatHistory(session.userId, 100);
  return sendJson(res, 200, { ok: true, history });
}

function requireAdmin(req, res) {
  const session = getSessionFromReq(req);
  if (!session || session.role !== 'admin') {
    sendJson(res, 401, { ok: false, error: 'Akses admin diperlukan.' });
    return null;
  }
  return session;
}

function handleAdminListUsers(req, res) {
  if (!requireAdmin(req, res)) return;
  const users = listUsersByRole('user');
  return sendJson(res, 200, { ok: true, users });
}

async function handleAdminBan(req, res) {
  if (!requireAdmin(req, res)) return;
  const body = await readJsonBody(req);
  const { username, banned } = body;
  if (typeof username !== 'string' || typeof banned !== 'boolean') {
    return sendJson(res, 400, { ok: false, error: 'Data tidak valid.' });
  }
  const success = setBanStatus(username.trim(), banned);
  if (!success) return sendJson(res, 404, { ok: false, error: 'User tidak ditemukan.' });
  return sendJson(res, 200, { ok: true });
}

// ---------- Router utama ----------
const routes = {
  'POST /api/register': handleRegister,
  'POST /api/login': handleLogin,
  'POST /api/admin/register': handleAdminRegister,
  'POST /api/admin/login': handleAdminLogin,
  'POST /api/logout': handleLogout,
  'GET /api/me': handleMe,
  'POST /api/chat': (req, res) => handleChat(req, res, 'user'),
  'GET /api/chat/history': (req, res) => handleChatHistory(req, res, 'user'),
  'POST /api/admin/chat': (req, res) => handleChat(req, res, 'admin'),
  'GET /api/admin/chat/history': (req, res) => handleChatHistory(req, res, 'admin'),
  'GET /api/admin/users': handleAdminListUsers,
  'POST /api/admin/ban': handleAdminBan,
};

const server = http.createServer(async (req, res) => {
  try {
    const urlObj = new URL(req.url, `http://${req.headers.host}`);
    const routeKey = `${req.method} ${urlObj.pathname}`;

    if (routes[routeKey]) {
      await routes[routeKey](req, res);
      return;
    }

    if (req.method === 'GET') {
      serveStatic(req, res, urlObj.pathname);
      return;
    }

    sendJson(res, 404, { ok: false, error: 'Route tidak ditemukan.' });
  } catch (err) {
    console.error('Server error:', err);
    if (!res.headersSent) {
      sendJson(res, 500, { ok: false, error: 'Terjadi kesalahan di server.' });
    }
  }
});

server.listen(PORT, () => {
  console.log(`✅ Server jalan di http://localhost:${PORT}`);
  console.log(`   Staff key untuk daftar admin: ${STAFF_KEY}`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.log('⚠️  ANTHROPIC_API_KEY belum diisi di .env — chat AI akan menampilkan pesan placeholder.');
  }
});
