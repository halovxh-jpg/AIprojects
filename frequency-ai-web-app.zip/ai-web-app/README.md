# Frequency — Web Chat AI dengan Login, Admin, dan Sistem Ban

Web app lengkap: registrasi/login (tersimpan di database SQLite), login admin dengan kunci
staff rahasia, dua "kepribadian" AI berbeda (Nova untuk user, Cipher untuk admin), sistem
ban akun, dan tampilan chat dengan bubble animasi. Dibuat **tanpa dependency npm apa pun**
— murni Node.js built-in (http, node:sqlite, crypto) — jadi tidak perlu `npm install`.

## Cara menjalankan

1. Pastikan Node.js versi **22 ke atas** terpasang (cek dengan `node -v`).
2. Salin `.env.example` menjadi `.env`:
   ```
   cp .env.example .env
   ```
3. Buka `.env` dan isi `ANTHROPIC_API_KEY` dengan API key kamu dari
   https://console.anthropic.com (biar AI-nya beneran bisa jawab). Tanpa key, aplikasi
   tetap jalan normal tapi AI akan membalas pesan placeholder yang menjelaskan key belum diisi.
4. Jalankan servernya:
   ```
   node server.js
   ```
5. Buka `http://localhost:3000` di browser.

Tidak ada `npm install` yang diperlukan — semua sudah pakai modul bawaan Node.js.

## Cara pakai

- **Daftar/Login pengguna biasa**: `/register.html` dan `/login.html` → setelah login
  diarahkan ke `/chat.html`, ngobrol dengan **Nova** (gaya santai mirip ChatGPT).
- **Daftar/Login admin**: `/admin-register.html` dan `/admin-login.html`. Untuk daftar
  admin, wajib isi **kunci staff**: `67COOL67` (bisa diganti lewat `STAFF_KEY` di `.env`).
  Setelah login, admin diarahkan ke `/admin-chat.html`, ngobrol dengan **Cipher**
  (fokus teknis/coding).
- **Kelola pengguna** (`/admin-dashboard.html`, link ada di header chat admin): admin bisa
  lihat semua akun pengguna biasa dan ban/unban dengan satu klik. Akun yang dibanned tidak
  bisa login lagi sampai di-unban.

## Struktur proyek

```
ai-web-app/
├── server.js        # Server HTTP + semua routing API
├── db.js             # Layer database (node:sqlite)
├── auth.js           # Hash password (scrypt) + session
├── ai.js              # Pemanggilan AI (dua persona: Nova & Cipher)
├── env.js             # Loader .env sederhana
├── data/app.sqlite    # Database (dibuat otomatis saat pertama run)
└── public/            # Semua halaman & aset frontend
```

## Keamanan yang sudah diterapkan

- Password di-hash dengan `scrypt` (bukan disimpan plain text).
- Session pakai cookie `HttpOnly` (tidak bisa diakses lewat JS di browser).
- Validasi input di server (bukan cuma di frontend).
- Proteksi path traversal di static file server.
- Kunci staff admin tidak pernah dikirim balik ke client.

## Kustomisasi

- **Ganti kunci staff admin**: ubah `STAFF_KEY` di `.env`.
- **Ganti nama/kepribadian AI**: edit `USER_SYSTEM_PROMPT` dan `ADMIN_SYSTEM_PROMPT`
  di `ai.js`.
- **Ganti model AI**: ubah `AI_MODEL` di `.env`.
- **Deploy online**: aplikasi ini bisa langsung di-deploy ke layanan apa pun yang
  mendukung Node.js 22+ (Railway, Render, VPS, dll). Pastikan set environment variable
  yang sama seperti di `.env`.

## Catatan

Session disimpan di memory server (bukan database), jadi kalau server di-restart,
semua orang perlu login ulang — akun dan riwayat chat tetap aman di database.
Untuk skala produksi dengan banyak pengguna, pertimbangkan pindah session ke database
juga.
