// Layer database pakai node:sqlite (built-in Node.js 22+, tanpa perlu install apa pun)
const path = require('node:path');
const fs = require('node:fs');
const { DatabaseSync } = require('node:sqlite');

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, 'app.sqlite'));

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    banned INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    sender TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

// ---------- Users ----------
function createUser({ username, passwordHash, role }) {
  const stmt = db.prepare(
    'INSERT INTO users (username, password, role, banned, created_at) VALUES (?, ?, ?, 0, ?)'
  );
  const info = stmt.run(username, passwordHash, role, new Date().toISOString());
  return Number(info.lastInsertRowid);
}

function findUserByUsername(username) {
  const stmt = db.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE');
  return stmt.get(username);
}

function findUserById(id) {
  const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
  return stmt.get(id);
}

function listUsersByRole(role) {
  const stmt = db.prepare('SELECT id, username, banned, created_at FROM users WHERE role = ? ORDER BY created_at DESC');
  return stmt.all(role);
}

function setBanStatus(username, banned) {
  const stmt = db.prepare("UPDATE users SET banned = ? WHERE username = ? COLLATE NOCASE AND role = 'user'");
  const info = stmt.run(banned ? 1 : 0, username);
  return Number(info.changes) > 0;
}

// ---------- Chat messages ----------
function addChatMessage(userId, sender, content) {
  const stmt = db.prepare(
    'INSERT INTO chat_messages (user_id, sender, content, created_at) VALUES (?, ?, ?, ?)'
  );
  stmt.run(userId, sender, content, new Date().toISOString());
}

function getChatHistory(userId, limit = 50) {
  const stmt = db.prepare(
    'SELECT sender, content, created_at FROM chat_messages WHERE user_id = ? ORDER BY id ASC LIMIT ?'
  );
  return stmt.all(userId, limit);
}

module.exports = {
  db,
  createUser,
  findUserByUsername,
  findUserById,
  listUsersByRole,
  setBanStatus,
  addChatMessage,
  getChatHistory,
};
